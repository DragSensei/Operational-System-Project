/*
 * test_working_set.c
 *
 *  Created on: Oct 13, 2023
 *      Author: HP
 */

#include <kern/tests/test_working_set.h>
#include <kern/proc/user_environment.h>
#include <kern/mem/working_set_manager.h>
#include <kern/cpu/cpu.h>
#include <kern/cpu/kclock.h>

//2020
int sys_check_LRU_lists(uint32* active_list_content, uint32* second_list_content, int actual_active_list_size, int actual_second_list_size)
{
	int active_list_validation = 1;
	int second_list_validation = 1;

	/*DISABLE THE INTERRUPT DURING THE CHECKING TO AVOID CLOCK INTERRUPTS*/
	pushcli(); kclock_stop();
	{
		struct Env* cur_env = get_cpu_proc();
		assert(cur_env != NULL);
		cprintf("CURRENT WS CONTENT BEFORE CHECKING:\n");
		env_page_ws_print(cur_env);

		struct Env* env = cur_env;
		struct WorkingSetElement* ptr_WS_element;

		//1- Check active list content if not null
		if(active_list_content != NULL)
		{
			int idx_active_list = 0;
			LIST_FOREACH(ptr_WS_element, &(env->ActiveList))
			{
				if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) != ROUNDDOWN(active_list_content[idx_active_list], PAGE_SIZE))
				{
					active_list_validation = 0;
					break;
				}
				idx_active_list++;
			}
			if(LIST_SIZE(&env->ActiveList) != actual_active_list_size)
			{
				active_list_validation = 0;

			}
		}

		//2- Check second chance list content if not null
		if(second_list_content != NULL)
		{
			int idx_second_list = 0;
			LIST_FOREACH(ptr_WS_element, &(env->SecondList))
			{
				if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) != ROUNDDOWN(second_list_content[idx_second_list], PAGE_SIZE))
				{
					second_list_validation = 0;
					break;
				}
				idx_second_list++;
			}
			if(LIST_SIZE(&env->SecondList) != actual_second_list_size)
				second_list_validation = 0;
		}
	}
	/*REENABLE THE INTERRUPT */
	popcli(); kclock_resume();

	return active_list_validation&second_list_validation;
}


//2020
int sys_check_LRU_lists_free(uint32* list_content, int list_size)
{
	int list_validation_count = 0;
	/*DISABLE THE INTERRUPT DURING THE CHECKING TO AVOID CLOCK INTERRUPTS*/
	pushcli(); kclock_stop();
	{
		struct Env* cur_env = get_cpu_proc();
		assert(cur_env != NULL);
		struct Env* env = cur_env;
		struct WorkingSetElement* ptr_WS_element;

		LIST_FOREACH(ptr_WS_element, &(env->ActiveList))
		{
			for(int var = 0; var < list_size; var++)
			{
				if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) == ROUNDDOWN(list_content[var], PAGE_SIZE))
				{
					list_validation_count++;
					break;
				}
			}
			if(list_validation_count > 0)
				break;
		}


		LIST_FOREACH(ptr_WS_element, &(env->SecondList))
		{
			for(int var = 0; var < list_size; var++)
			{
				if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) == ROUNDDOWN(list_content[var], PAGE_SIZE))
				{
					list_validation_count++;
					break;
				}
			}
			if(list_validation_count > 0)
				break;

		}
	}
	/*REENABLE THE INTERRUPT */
	popcli(); kclock_resume();

	return list_validation_count;
}

//2023
/*chk_status:
 * = 0: check entire list (order is not important)
 * = 1: check entire list (order is important)
 * = 2: check only the existence of the given set of elements
 * = 3: check only the NOT existence of the given set of elements
 */
int sys_check_WS_list(uint32* WS_list_content, int actual_WS_list_size, uint32 last_WS_element_content, bool chk_status)
{
#if USE_KHEAP
	int WS_list_validation = 1;
	/*DISABLE THE INTERRUPT DURING THE CHECKING TO AVOID CLOCK INTERRUPTS*/
	pushcli(); kclock_stop();
	{
//		cprintf("CURRENT WS CONTENT BEFORE CHECKING:\n");
//		env_page_ws_print(get_cpu_proc());
		struct Env* cur_env = get_cpu_proc();
		assert(cur_env != NULL);
		struct Env* env = cur_env;
		struct WorkingSetElement* ptr_WS_element;

		if (chk_status == 0 || chk_status == 1)
		{
			if(LIST_SIZE(&(env->page_WS_list)) != actual_WS_list_size)
			{
				WS_list_validation = 0;
			}
		}
		//if it's required to check the last_WS_element
		if (last_WS_element_content != 0)
		{
			if (ROUNDDOWN(env->page_last_WS_element->virtual_address, PAGE_SIZE) != ROUNDDOWN(last_WS_element_content, PAGE_SIZE))
			{
				WS_list_validation = 0;
			}
		}

		if (WS_list_validation)
		{
			//if the order of the content is important to check
			if (chk_status == 1)
			{
				int idx_WS_list = 0;

				//Search for the correct index of the current WS element (if any)
				if (env->page_last_WS_element)
				{
					for (int i = 0; i < actual_WS_list_size; ++i)
					{
						if (ROUNDDOWN(WS_list_content[i], PAGE_SIZE) == ROUNDDOWN(env->page_last_WS_element->virtual_address, PAGE_SIZE))
						{
							idx_WS_list = i ;
							break;
						}
					}
				}
				//cprintf("index of last WS element = %d\n",idx_WS_list);
				//Check the expected content starting from last WS element (if any)
				if (env->page_last_WS_element)
					ptr_WS_element = env->page_last_WS_element;
				else
					ptr_WS_element = LIST_FIRST(&(env->page_WS_list));

				//cprintf("comparison start from va = %x\n",ptr_WS_element->virtual_address);

				for (int i = 0; i < actual_WS_list_size; ++i)
				{
					//cprintf("check against index %d, va = %x\n", idx_WS_list, ptr_WS_element->virtual_address);
					if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) != ROUNDDOWN(WS_list_content[idx_WS_list], PAGE_SIZE))
					{
						cprintf("WS MISMATCHED @INDEX %d!!! Actual = %x Expected = %x\n",idx_WS_list, ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE), ROUNDDOWN(WS_list_content[idx_WS_list], PAGE_SIZE));
						WS_list_validation = 0;
						break;
					}
					idx_WS_list = (idx_WS_list + 1) % env->page_WS_max_size;
					ptr_WS_element = LIST_NEXT(ptr_WS_element);
					if (ptr_WS_element == NULL)
						ptr_WS_element = LIST_FIRST(&(env->page_WS_list));
				}
			}
			else if (chk_status == 0 || chk_status == 2)
			{
				for (int idx_expected_list = 0; idx_expected_list < actual_WS_list_size; ++idx_expected_list)
				{
					bool found = 0;
					LIST_FOREACH(ptr_WS_element, &(env->page_WS_list))
					{
						if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) == ROUNDDOWN(WS_list_content[idx_expected_list], PAGE_SIZE))
						{
							//if previously found (i.e. duplicated), return false
							if (found)
							{
								cprintf("DUPLICATED ADDRESS IN WS!!! VA = %x\n", ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE));
								WS_list_validation = 0;
								break;
							}
							found = 1;
						}
					}
					if (!found)
					{
						cprintf("ADDRESS NOT FOUND IN WS!!! VA = %x\n", ROUNDDOWN(WS_list_content[idx_expected_list], PAGE_SIZE));
						WS_list_validation = 0;
						break;
					}
				}
			}
			//Check NON-EXITENCE of the Given Addresses
			else if (chk_status == 3)
			{
				for (int idx_expected_list = 0; idx_expected_list < actual_WS_list_size; ++idx_expected_list)
				{
					bool found = 0;
					LIST_FOREACH(ptr_WS_element, &(env->page_WS_list))
					{
						if (ROUNDDOWN(ptr_WS_element->virtual_address, PAGE_SIZE) == ROUNDDOWN(WS_list_content[idx_expected_list], PAGE_SIZE))
						{
							found = 1;
							break;
						}
					}
					if (found)
					{
						cprintf("ADDRESS FOUND IN WS WHILE NOT EXPECTED TO!!! VA = %x\n", ROUNDDOWN(WS_list_content[idx_expected_list], PAGE_SIZE));
						WS_list_validation = 0;
						break;
					}
				}
			}
		}
	}
	/*REENABLE THE INTERRUPT */
	popcli(); kclock_resume();

	return WS_list_validation;
#else
	panic("sys_check_WS_list: this function is intended to be used when USE_KHEAP = 1");
	return 0;
#endif
}
